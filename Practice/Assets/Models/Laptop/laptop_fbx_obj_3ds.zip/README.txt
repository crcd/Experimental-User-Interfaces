+--------+
| Laptop |
+--------+

While Fun Games

http://www.whilefun.com
twitter: @whilefun
info@whilefun.com


Notes:
-----
A very low poly 3D model of a laptop


Enjoy!
Richard